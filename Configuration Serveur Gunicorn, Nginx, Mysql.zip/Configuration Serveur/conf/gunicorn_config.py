command = '/home/toto/django_env/bin/gunicorn'
pythonpath = '/home/toto/filmographie'
bind = '192.168.189.136:8000'
workers = 3
